﻿console.log('calendar.js placeholder');

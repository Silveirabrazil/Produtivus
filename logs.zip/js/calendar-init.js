// Encaminhado para o novo inicializador da página
(function(){
  try {
    var s = document.createElement('script');
    s.src = 'js/pages/calendario.js?v=20250907';
    s.defer = true;
    document.head.appendChild(s);
  } catch (e) {}
})();

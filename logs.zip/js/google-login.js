// js/google-login.js

// Sistema expandido de autenticação Google com suporte a Calendar API
class GoogleAuth {
  constructor() {
    this.gapi = null;
    this.authInstance = null;
    this.isInitialized = false;
  }

  // Inicialização para One Tap (login básico)
  async initOneTap() {
    // Manter compatibilidade com sistema atual
    return true;
  }

  // Inicialização para OAuth com scopes (Calendar API)
  async initOAuth() {
    try {
      // Carregar Google API JavaScript client
      if (!window.gapi) {
        await this.loadGoogleAPI();
      }

      await new Promise((resolve) => {
        window.gapi.load('auth2', resolve);
      });

      // Configurar OAuth com scopes do Calendar
      this.authInstance = await window.gapi.auth2.init({
        client_id: await this.getClientId(),
        scope: 'openid email profile https://www.googleapis.com/auth/calendar.readonly'
      });

      this.isInitialized = true;
      console.info('[GoogleAuth] OAuth inicializado com scopes de Calendar');
      return true;
    } catch (error) {
      console.error('[GoogleAuth] Erro ao inicializar OAuth:', error);
      return false;
    }
  }

  // Carregar Google API dinamicamente
  async loadGoogleAPI() {
    return new Promise((resolve, reject) => {
      if (window.gapi) {
        resolve();
        return;
      }

      const script = document.createElement('script');
      script.src = 'https://apis.google.com/js/api.js';
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });
  }

  // Obter Client ID do servidor
  async getClientId() {
    try {
      const response = await fetch('/server/api/oauth_config.php');
      const data = await response.json();
      return data.googleClientId || '';
    } catch (error) {
      console.error('[GoogleAuth] Erro ao obter Client ID:', error);
      return '';
    }
  }

  // Login com permissões de Calendar
  async signInWithCalendar() {
    try {
      if (!this.isInitialized) {
        const initialized = await this.initOAuth();
        if (!initialized) {
          throw new Error('Falha ao inicializar OAuth');
        }
      }

      const authResult = await this.authInstance.signIn();
      const profile = authResult.getBasicProfile();
      const accessToken = authResult.getAuthResponse().access_token;

      // Enviar dados completos para o backend
      const loginData = {
        id_token: authResult.getAuthResponse().id_token,
        access_token: accessToken,
        email: profile.getEmail(),
        name: profile.getName(),
        calendar_access: true
      };

      const response = await fetch('/server/api/google_login.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(loginData)
      });

      const data = await response.json();

      if (data.success) {
        // Salvar dados do usuário incluindo permissões de calendário
        const user = {
          ...data.user,
          calendar_access: true,
          access_token: accessToken
        };

        localStorage.setItem('pv_user', JSON.stringify(user));
        localStorage.setItem('pv_google_calendar_token', accessToken);

        // Notificar sobre conexão do calendário
        setTimeout(() => {
          window.pvNotify?.({
            title: `Bem-vindo, ${user.name}!`,
            message: 'Login concluído com acesso ao Google Calendar.',
            type: 'success'
          });
        }, 300);

        window.location.href = 'index.html';
      } else {
        throw new Error(data.message || 'Falha no login');
      }
    } catch (error) {
      console.error('[GoogleAuth] Erro no login com Calendar:', error);
      (window.pvShowToast || alert)('Erro ao conectar com Google Calendar: ' + error.message);
    }
  }
}

// Instância global
window.googleAuth = new GoogleAuth();

// Função legacy para compatibilidade (One Tap)
function handleCredentialResponse(response) {
  // Token JWT do Google
  const idToken = response.credential;
  // Envia para o backend validar e autenticar
  fetch('/server/api/google_login.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id_token: idToken })
  })
  .then(r => r.json())
    .then(data => {
    if (data.success) {
      // Salva usuário no localStorage antes de redirecionar (com nome se disponível)
      const user = data.user || { email: data.email || '' };
      if (!user.name && user.email) { user.name = String(user.email).split('@')[0]; }
      localStorage.setItem('pv_user', JSON.stringify(user));

      // Perguntar se quer conectar calendário
      setTimeout(() => {
        const connectCalendar = confirm('Login realizado! Deseja conectar seu Google Calendar para sincronizar eventos?');
        if (connectCalendar) {
          window.googleAuth.signInWithCalendar().catch(() => {
            // Se falhar, continuar sem calendário
            window.location.href = 'index.html';
          });
        } else {
          window.location.href = 'index.html';
        }
      }, 100);
    } else {
      (window.pvShowToast||((m)=>alert(m)))('Falha no login Google: ' + (data.message || ''));
    }
  })
  .catch(error => {
    (window.pvShowToast||((m)=>alert(m)))('Erro na comunicação com o servidor.');
    console.error(error);
  });
}

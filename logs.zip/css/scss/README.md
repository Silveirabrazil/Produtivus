Padroniza c3 a7 c3 a3o para partials SCSS
======================================

Objetivo
--------
Ao criar estilos para uma parte do site (por exemplo: Estudos, Flashcards, Header, Footer), crie um novo partial SCSS separado em `css/scss/` com o prefixo `_` e um nome descritivo, por exemplo:

- `css/scss/_estudos.scss`  // estilos específicos da se c3 a7 c3 a3o Estudos
- `css/scss/_flashcards.scss`

Regras simples
-------------
- Nome do ficheiro: snake-case, iniciando por `_` e sem sufixo `.scss` no `@import` (ex.: `_estudos.scss` -> `@import "estudos";`).
- Cada partial deve conter apenas estilos referentes  c3 a0quela parte do site (layout, espa c3 a7amentos, overrides bootstrap locais).
- Evitar selectors globais muito gen c3 a9ricos (use um prefixo ou class local, ex.: `.estudos-hub`).
- Documente no topo do partial o objetivo e elementos afetados.

Como importar
--------------
Edite `css/scss/styles.scss` e adicione uma linha `@import "nome-do-partial";` onde `nome-do-partial` corresponde ao ficheiro sem o `_` e sem a extens c3 a3o.

Exemplo
-------
1. Criar `css/scss/_estudos.scss` com regras locais.
2. Em `css/scss/styles.scss` adicionar `@import "estudos";`.
3. Rodar `npm run build:css` para compilar `css/styles.css`.

Checks e boas pr c3 a1ticas
-------------------------
- Prefira classes semanticamente relacionadas ao componente para facilitar manutenção.
- Evite usar `!important` salvo quando for a  c3 baltima op c3 a7 c3 a3o.
- Sempre faça um teste visual em `estudos.html` (ou p c3gina equivalente) ap c3 f3s compilar.

Se quiser, posso adicionar um pequeno script que detecta novos partials e os importa automaticamente em `styles.scss`.

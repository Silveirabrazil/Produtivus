<?php
// CRUD de páginas de caderno do usuário autenticado
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/_auth_guard.php';
require_once __DIR__ . '/../config/database.php';

$uid = (int)($_SESSION['user_id'] ?? 0);
if ($uid <= 0) { http_response_code(401); echo json_encode(['success'=>false,'message'=>'Não autenticado']); exit; }

function read_json_body() {
  $raw = file_get_contents('php://input');
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}

try {
  $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
  if ($method === 'OPTIONS') { http_response_code(204); exit; }

  if ($method === 'GET') {
    $nid = isset($_GET['notebook_id']) ? (int)$_GET['notebook_id'] : 0;
    if ($nid<=0) { http_response_code(400); echo json_encode(['success'=>false,'message'=>'notebook_id obrigatório']); exit; }
    // valida posse
    $chk = $conn->prepare('SELECT id FROM notebooks WHERE id=:id AND user_id=:uid');
    $chk->execute([':id'=>$nid, ':uid'=>$uid]);
    if (!$chk->fetch()) { http_response_code(404); echo json_encode(['success'=>false,'message'=>'Caderno não encontrado']); exit; }

    // Tenta selecionar com todas as colunas; se falhar (colunas ausentes), faz fallback com colunas básicas
    try {
      $st = $conn->prepare('SELECT id, notebook_id, title, color, content, subject_id, created_at, updated_at FROM notebook_pages WHERE notebook_id = :nid ORDER BY id ASC');
      $st->execute([':nid'=>$nid]);
      $rows = $st->fetchAll();
      $items = array_map(function($r){ return [ 'id'=>(int)$r['id'], 'title'=>$r['title'], 'color'=>$r['color'], 'content'=>$r['content'], 'subject_id'=> isset($r['subject_id']) ? (int)$r['subject_id'] : null, 'created'=>$r['created_at'] ?? null, 'updated'=>$r['updated_at'] ?? null ]; }, $rows);
    } catch (Throwable $e) {
      // Fallback: sem subject_id/created_at/updated_at
      $st = $conn->prepare('SELECT id, notebook_id, title, color, content FROM notebook_pages WHERE notebook_id = :nid ORDER BY id ASC');
      $st->execute([':nid'=>$nid]);
      $rows = $st->fetchAll();
      $items = array_map(function($r){ return [ 'id'=>(int)$r['id'], 'title'=>$r['title'], 'color'=>$r['color'], 'content'=>$r['content'], 'subject_id'=> null, 'created'=> null, 'updated'=> null ]; }, $rows);
    }
    echo json_encode(['success'=>true, 'items'=>$items]);
    exit;
  }

  if ($method === 'POST') {
    $b = read_json_body();
    $nid = (int)($b['notebook_id'] ?? 0);
    if ($nid<=0) { http_response_code(400); echo json_encode(['success'=>false,'message'=>'notebook_id obrigatório']); exit; }
    $chk = $conn->prepare('SELECT id FROM notebooks WHERE id=:id AND user_id=:uid');
    $chk->execute([':id'=>$nid, ':uid'=>$uid]);
    if (!$chk->fetch()) { http_response_code(404); echo json_encode(['success'=>false,'message'=>'Caderno não encontrado']); exit; }

    $title = trim((string)($b['title'] ?? 'Página'));
    $color = isset($b['color']) ? (string)$b['color'] : null;
    $content = isset($b['content']) ? (string)$b['content'] : '';
    $subjectId = isset($b['subject_id']) && $b['subject_id'] !== '' ? (int)$b['subject_id'] : null;
    // Tenta inserir com subject_id; se falhar (coluna ausente), insere sem ela
    try {
      $st = $conn->prepare('INSERT INTO notebook_pages (notebook_id, title, color, content, subject_id) VALUES (:nid,:t,:c,:ct,:sid)');
      $st->execute([':nid'=>$nid, ':t'=>$title, ':c'=>$color, ':ct'=>$content, ':sid'=>$subjectId]);
    } catch (Throwable $e) {
      $st = $conn->prepare('INSERT INTO notebook_pages (notebook_id, title, color, content) VALUES (:nid,:t,:c,:ct)');
      $st->execute([':nid'=>$nid, ':t'=>$title, ':c'=>$color, ':ct'=>$content]);
    }
    echo json_encode(['success'=>true, 'id'=>(int)$conn->lastInsertId()]);
    exit;
  }

  if ($method === 'PUT' || $method === 'PATCH') {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if ($id<=0) { http_response_code(400); echo json_encode(['success'=>false,'message'=>'ID inválido']); exit; }
    // garante posse via join
    $chk = $conn->prepare('SELECT p.id FROM notebook_pages p INNER JOIN notebooks n ON n.id = p.notebook_id WHERE p.id=:id AND n.user_id=:uid');
    $chk->execute([':id'=>$id, ':uid'=>$uid]);
    if (!$chk->fetch()) { http_response_code(404); echo json_encode(['success'=>false,'message'=>'Página não encontrada']); exit; }

    $b = read_json_body();
    $fields = [];$params=[':id'=>$id];
    if (isset($b['title'])) { $fields[]='title=:t'; $params[':t']=(string)$b['title']; }
  if (isset($b['color'])) { $fields[]='color=:c'; $params[':c']=(string)$b['color']; }
  if (array_key_exists('content',$b)) { $fields[]='content=:ct'; $params[':ct']=$b['content']; }
  if (array_key_exists('subject_id',$b)) { $fields[]='subject_id=:sid'; $params[':sid']= ($b['subject_id'] !== '' && $b['subject_id'] !== null) ? (int)$b['subject_id'] : null; }
    if ($fields){
      try {
        $sql='UPDATE notebook_pages SET '.implode(',', $fields).' WHERE id=:id';
        $up=$conn->prepare($sql); $up->execute($params);
      } catch (Throwable $e) {
        // Se falhar por causa de subject_id ausente, remove-o e tenta novamente
        $fields2 = [];$params2=[':id'=>$id];
        if (isset($b['title'])) { $fields2[]='title=:t'; $params2[':t']=(string)$b['title']; }
        if (isset($b['color'])) { $fields2[]='color=:c'; $params2[':c']=(string)$b['color']; }
        if (array_key_exists('content',$b)) { $fields2[]='content=:ct'; $params2[':ct']=$b['content']; }
        if ($fields2) { $sql='UPDATE notebook_pages SET '.implode(',', $fields2).' WHERE id=:id'; $up=$conn->prepare($sql); $up->execute($params2); }
      }
    }
    // Força atualização do campo updated_at, se existir
    try { $sqlUpdateTime = 'UPDATE notebook_pages SET updated_at=NOW() WHERE id=:id'; $upTime = $conn->prepare($sqlUpdateTime); $upTime->execute([':id'=>$id]); } catch (Throwable $e) {}
    echo json_encode(['success'=>true]);
    exit;
  }

  if ($method === 'DELETE') {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if ($id<=0) { http_response_code(400); echo json_encode(['success'=>false,'message'=>'ID inválido']); exit; }
    $del = $conn->prepare('DELETE p FROM notebook_pages p INNER JOIN notebooks n ON n.id = p.notebook_id WHERE p.id=:id AND n.user_id=:uid');
    $del->execute([':id'=>$id, ':uid'=>$uid]);
    echo json_encode(['success'=>true]);
    exit;
  }

  http_response_code(405);
  echo json_encode(['success'=>false,'message'=>'Método não suportado']);
} catch (Throwable $e) {
  if (function_exists('error_log')) error_log('[Produtivus][notebook_pages] '.$e->getMessage());
  http_response_code(500);
  echo json_encode(['success'=>false,'message'=>'Erro interno']);
}

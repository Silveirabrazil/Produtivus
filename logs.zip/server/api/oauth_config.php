<?php
// server/api/oauth_config.php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

try {
    // Carregar configurações do OAuth
    $configPath = __DIR__ . '/../config/app.php';

    if (file_exists($configPath)) {
        $config = require $configPath;

        // Retornar apenas informações públicas necessárias
        $response = [
            'success' => true,
            'googleClientId' => $config['google']['client_id'] ?? '',
            'calendarSupport' => !empty($config['google']['client_id'])
        ];
    } else {
        // Fallback se não houver configuração
        $response = [
            'success' => false,
            'googleClientId' => '',
            'calendarSupport' => false,
            'message' => 'Configuração OAuth não encontrada'
        ];
    }

    echo json_encode($response);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'googleClientId' => '',
        'calendarSupport' => false,
        'message' => 'Erro ao carregar configuração OAuth'
    ]);
}
?>
